<?php
class Db{ 
var $servername , $username , $password , $dbname ;
var $conn ;

function __construct($servername , $username , $password , $dbname)
{//connection string to DB 
    $this->servername = $servername;
    $this->username= $username;
    $this->password = $password;
    $this->username = $username;
    $this->conn = mysqli_connect(
     $this->servername , 
     $this->username , 
     $this->password,
     $this->dbname
    );
}
}
$DB = new Db('localhost' , 'root','','KFC');
