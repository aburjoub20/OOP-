<?php
class User{
var $Name , $Email , $Password; //create variable
var $is_Admin = false;
function hello(){
    echo "hello  $this->Name";
}
function __construct($Name , $Email , $Password)
{
    $this->Name = $Name; //name :key /$name : nalue
    $this->Email = $Email;
    $this->Password = $Password;
    echo "hello from constructur $this->Name " ; 
}
}
$u1 = new User('ahmad' , 'ah,ad@gmail' , '123');

//$u1->Name = 'baby';
//$u1->Email = 'Areeno@gamil.com';
//$u1->Password = "123";
$u1->hello();

?>