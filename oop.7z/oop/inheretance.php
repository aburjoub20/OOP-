<?php
//var by defult public 
//inheretance 
//final to deny class inhertance 
//encapsolation protected public private 
//abstract can not create obect just inhertnace for child to save proparety value 
//to inhert function abstract you must set class abstract ;
//if class abstract you must set body to method if method not abstract ;
 //inhertinac / abstract 
class User{
private $name,$password,$email;
private $test ='private';
function __construct($name , $password , $email)
{
    $this->name = $name;
    $this->password = $password;
    $this->email = $email;
}
//abstract
function abc(){
    echo "hello";
}
//override
function hello(){
    echo "hello user";
}
}
class Ahmad extends User{
    function hello(){
        echo "hello areeno <3 ";
    }
}
$a1 = new User('ahmad' , '123' , 'ahmad@gmail');
echo $test;
echo '<pre>';
print_r($a1);
echo'</pre>';
$a1->hello(); //override 
?>