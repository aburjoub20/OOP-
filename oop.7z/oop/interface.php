<?php
//interface 
//interface to gide to create general form for method and set permitions for write code 
//besnefits to set path of class .
//to print a variable via function no need to use (this-> 
//interface just form without function body
//abstract you can set body for  methods 
interface payment{
    public function price($mony);
    public function charge();
}
class visa implements payment {
    public function price($mony){
        echo "hello  $mony";
    }
    public function charge(){}
}
$v1 = new visa();
$v1->price('5');
?>