<?php
namespace Auth;//namespace path
class User{

    function __construct()
    {
        echo "hello auth ";
    }
}


?>