<?php
namespace Pay;//namespace path
class User{

    function __construct() //create by defult when call class
    {
        echo "hello Pay ";
    }
}


?>