
<?php
require_once("Auth.php"); 
require_once("Pay.php");//connect to file
use Auth\User as AuthU;
use Auth\Pay as PayU;//shortcut namesapce 
//define user path to know which user class call and create shourtcut to deny name collation 
 //this class name in all file without name collation 
 $u1 = new AuthU;
 $u2 = new PayU;
?>