<?php
// opertion calculate
class Cal{
var $num1 , $num2;
function __construct($num1 , $num2)
{
    $this->num1 = $num1;
    $this->num2 = $num2;
}
function sum (){
    return $this->num1 + $this->num2;
}
function div (){ 
    return $this->num1 / $this->num2;
}
function __destruct()
{
    echo"goodbay";
}
}
$d1 = new Cal(8 , 2);
echo '<pre>';
echo $d1->sum();
echo '</pre>';
echo $d1->div();
echo '<pre>';
echo '</pre>';


?>