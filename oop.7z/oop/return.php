<?php
class number{
public $number;
function __construct($num){//construct call when creae object of class
    $this->number = $num; //$this use to call proparity  
}
function addone(){
$this->number+=1; //number = number +1 
return $this;
}
function addtow(){
    $this->number+=2;
}
}
$n1 = new number(5);
echo $n1 = $this->addtow();
$n1 = $this->addone();
//you didnot use echo when you use #return for proparity (this); 

?>