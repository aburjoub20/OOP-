<?php
//static used to call methodes without createb object 
//www.ahmad.com/the new product name 
//can not call proparites non static 
class str{
    public static $test = "hello";//stric class
    static function makeSlug($name){
        $slug = str_replace(" ", "-",$name);//replace function  space to - 
        echo self::$test;//::to call method staric
        return $slug ;
    }
}
echo str::makeSlug("ahmad rjoub " );
?>