<?php
//trait horizntal inheritancce 
//the differnt between class and trait is trait can not create object 
class C{
   use A , B ;
}
trait A{
    public function pay(){
        echo "hello pay";
    }
}
trait B {
    public function Buy (){
        echo "hello Buy";
    }
}

$c  = new C; //create object class C
$c -> pay();
$c ->Buy();//call methods

?>